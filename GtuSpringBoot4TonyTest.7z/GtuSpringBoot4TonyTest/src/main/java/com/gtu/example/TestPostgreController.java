package com.gtu.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicReference;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * @author wistronits
 *         http://localhost:8090/GtuSpringBoot4Tony/test-postgre/insert_avg/3/16
 */
@RestController
@RequestMapping("/test-postgre/")
public class TestPostgreController {

    private static Logger logger = LoggerFactory.getLogger(TestPostgreController.class);

    private static SimpleDateFormat SDF = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSSSSS");;

    @Value("${driverClassName}")
    private String driverClassName;
    @Value("${url}")
    private String url;
    @Value("${username1}")
    private String username;
    @Value("${password}")
    private String password;

    private AtomicReference<DataSource> dataSource = new AtomicReference<DataSource>();

    @GetMapping(value = "/test")
    public String test() {
        logger.info("#- test ");
        try {
        } catch (Exception e) {
            e.printStackTrace();
            return ExceptionUtils.getFullStackTrace(e);
        } finally {
        }
        return "test success..";
    }

    @GetMapping(value = "/rows/{rows}")
    public String test2000rows(@PathVariable("rows") String rows, HttpServletRequest request, HttpServletResponse response) {
        try {
            int rowCount = Integer.parseInt(rows);

            ExecutorService executor = Executors.newFixedThreadPool(rowCount);

            List<InnerCallable> lst = new ArrayList<InnerCallable>();
            for (int ii = 0; ii < rowCount; ii++) {
                InnerCallable innerThread = new InnerCallable("thread[" + ii + "]");
                lst.add(innerThread);
            }

            List<Future<JSONObject>> rtnLst = executor.invokeAll(lst);

            JSONArray arry = new JSONArray();
            rtnLst.stream().map(f -> {
                try {
                    return f.get();
                } catch (Exception e) {
                    return "fail";
                }
            }).forEach(v -> {
                arry.add(v);
            });
            return arry.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return ExceptionUtils.getFullStackTrace(e);
        } finally {
        }
    }

    @GetMapping(value = "/insert_seq/{rows}")
    public String insert_seq(@PathVariable("rows") String rows, HttpServletRequest request, HttpServletResponse response) {
        try {
            int rowCount = Integer.parseInt(rows);

            String result = this.insertMaster("seq_name_", rowCount);

            JSONObject obj = new JSONObject();
            obj.put("result", result);
            return obj.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return ExceptionUtils.getFullStackTrace(e);
        } finally {
        }
    }

    @GetMapping(value = "/insert_con/{thread}/{max_rows}")
    public String insert_concurrent(@PathVariable("thread") String thread, @PathVariable("max_rows") String maxRows, HttpServletRequest request, HttpServletResponse response) {
        try {
            int threadCnt = Integer.parseInt(thread);
            int maxRowsCnt = Integer.parseInt(maxRows);

            ExecutorService executor = Executors.newFixedThreadPool(threadCnt);

            List<ConInsertCallable> lst = new ArrayList<ConInsertCallable>();
            for (int ii = 0; ii < threadCnt; ii++) {
                ConInsertCallable innerThread = new ConInsertCallable("thread[" + ii + "]", maxRowsCnt);
                lst.add(innerThread);
            }

            List<Future<JSONObject>> rtnLst = executor.invokeAll(lst);

            JSONArray arry = new JSONArray();
            rtnLst.stream().map(f -> {
                try {
                    return f.get();
                } catch (Exception e) {
                    return "fail";
                }
            }).forEach(v -> {
                arry.add(v);
            });
            return arry.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return ExceptionUtils.getFullStackTrace(e);
        } finally {
        }
    }

    @GetMapping(value = "/insert_avg/{thread}/{max_rows}")
    public String insert_avg(@PathVariable("thread") String thread, @PathVariable("max_rows") String maxRows, HttpServletRequest request, HttpServletResponse response) {
        try {
            int threadCnt = Integer.parseInt(thread);
            int $maxRowsCnt = Integer.parseInt(maxRows);

            int maxRowsCnt = $maxRowsCnt / threadCnt;

            System.out.println("## 起  thread count : " + threadCnt);
            System.out.println("## 總  row count : " + $maxRowsCnt);
            System.out.println("## 平均  row count : " + maxRowsCnt);

            ExecutorService executor = Executors.newFixedThreadPool(threadCnt);

            List<ConInsertCallable> lst = new ArrayList<ConInsertCallable>();
            for (int ii = 0; ii < threadCnt; ii++) {
                ConInsertCallable innerThread = new ConInsertCallable("thread[" + ii + "]", maxRowsCnt);
                lst.add(innerThread);
            }

            List<Future<JSONObject>> rtnLst = executor.invokeAll(lst);

            JSONArray arry = new JSONArray();
            rtnLst.stream().map(f -> {
                try {
                    return f.get();
                } catch (Exception e) {
                    return "fail";
                }
            }).forEach(v -> {
                arry.add(v);
            });
            return arry.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return ExceptionUtils.getFullStackTrace(e);
        } finally {
        }
    }

    private String insertMaster(String threadName, int rowCnt) {
        PreparedStatement pstmt = null;
        Connection conn = null;
        try {
            long startTime = System.currentTimeMillis();

            conn = getConnection();
            String sql = " insert into master (id, \"NAME\", gneder, address) values (nextval( 'phonebook_id_seq'),?,?,?) ";
            pstmt = conn.prepareStatement(sql);

            for (int ii = 0; ii < rowCnt; ii++) {
                pstmt.setString(1, StringUtils.rightPad(threadName + ii, 100, "_"));
                pstmt.setString(2, "f");
                pstmt.setString(3, StringUtils.rightPad("address" + ii, 411, "_"));
                pstmt.addBatch();

                if (ii % 10000 == 0) {
                    System.out.println("procede : " + ii);
                    pstmt.executeBatch();
                }
            }

            pstmt.executeBatch();

            long duringTime = System.currentTimeMillis() - startTime;

            return String.format("row:%d, during:%d", rowCnt, duringTime);
        } catch (Exception ex) {
            ex.printStackTrace();
            return "ERR";
        } finally {
            try {
                pstmt.close();
            } catch (Exception ex) {
            }
            try {
                conn.close();
            } catch (Exception ex) {
            }
        }
    }

    private class ConInsertCallable implements Callable<JSONObject> {

        String name;
        int rowCnt;

        public ConInsertCallable(String name, int rowCnt) {
            this.name = name;
            this.rowCnt = rowCnt;
        }

        public JSONObject call() throws Exception {
            JSONObject obj = new JSONObject();
            System.out.println("ConInsertCallable----start time :　" + SDF.format(new Date()));
            try {
                System.out.println("Start----" + name);
                insertMaster(name, rowCnt);
                System.out.println("End----" + name + " --> Done ");
                obj.put(name, "success");
            } catch (Exception ex) {
                obj.put(name, ex.getMessage());
            }
            System.out.println("ConInsertCallable----end time :　" + SDF.format(new Date()));
            return obj;
        }
    }

    private class InnerCallable implements Callable<JSONObject> {

        String name;

        public InnerCallable(String name) {
            this.name = name;
        }

        public JSONObject call() throws Exception {
            JSONObject obj = new JSONObject();
            System.out.println("InnerCallable----start time :　" + SDF.format(new Date()));
            try {
                System.out.println("Start----" + name);
                List<Map<String, Object>> lst = doQuery();
                System.out.println("End----" + name + " --> " + lst.size());
                obj.put(name, "success");
            } catch (Exception ex) {
                obj.put(name, ex.getMessage());
            }
            System.out.println("InnerCallable----start time :　" + SDF.format(new Date()));
            return obj;
        }
    }

    public DataSource getPostgresDataSource() {
        DriverManagerDataSource bds = new DriverManagerDataSource();
        bds.setUrl(url);
        bds.setUsername(username);
        bds.setPassword(password);
        bds.setDriverClassName(driverClassName);
        logger.info("driverClassName = {}", driverClassName);
        logger.info("url = {}", url);
        logger.info("username = {}", username);
        logger.info("password = {}", password);
        return bds;
    }

    public Connection getConnection() throws SQLException {
        if (dataSource.get() == null) {
            dataSource.set(getPostgresDataSource());
        }
        return dataSource.get().getConnection();
    }

    public List<Map<String, Object>> doQuery() {
        List<Map<String, Object>> lst = new ArrayList<Map<String, Object>>();
        PreparedStatement pstmt = null;
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = getConnection();

            String sql = "select * from master where 1 =1 ";
            conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            List<String> colLst = new ArrayList<String>();
            for (int ii = 1; ii <= rsmd.getColumnCount(); ii++) {
                colLst.add(rsmd.getColumnLabel(ii));
            }
            while (rs.next()) {
                Map<String, Object> map = new HashMap<String, Object>();
                for (String col : colLst) {
                    map.put(col, rs.getObject(col));
                }
                lst.add(map);
            }
            return lst;
        } catch (Exception ex) {
            ex.printStackTrace();
            return Collections.emptyList();
        } finally {
            try {
                pstmt.close();
            } catch (Exception ex) {
            }
            try {
                rs.close();
            } catch (Exception ex) {
            }
            try {
                conn.close();
            } catch (Exception ex) {
            }
        }
    }
}
