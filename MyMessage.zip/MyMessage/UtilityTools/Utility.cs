﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace UtilityTools
{
    public class Utility
    {
        public Utility() { }

        /// <summary>
        /// 分隔字元
        /// </summary>
        public const char chrStep = (char)255;

        /// <summary>
        /// 加密密碼
        /// </summary>
        public const string EncryptPwd = "okdfba0210";

        /// <summary>
        /// 取得聯絡人資料表格式
        /// </summary>
        /// <returns>DataTable</returns>
        public static DataTable CreateContractTable()
        {
            DataTable dt = new DataTable("Contract");
            dt.Columns.Add(new DataColumn("NickName", typeof(string)));
            dt.Columns.Add(new DataColumn("IP", typeof(string)));
            dt.Columns.Add(new DataColumn("PORT", typeof(string)));
            dt.Columns.Add(new DataColumn("Status", typeof(string)));
            return dt;
        }

        public static DataTable CreateFontTable()
        {
            DataTable dt = new DataTable("Font");
            dt.Columns.Add(new DataColumn("FontFamily", typeof(string)));
            dt.Columns.Add(new DataColumn("Size", typeof(string)));
            dt.Columns.Add(new DataColumn("Style", typeof(string)));
            dt.Columns.Add(new DataColumn("Color", typeof(string)));
            return dt;
        }

        //SendMessage Code
        public const int WM_COPYDATA = 0x4A;

        [DllImport("User32.dll")]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
 
        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, ref COPYDATASTRUCT lParam);

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImport("imm32.dll")]
        public static extern IntPtr ImmGetContext(IntPtr hWnd);

        [DllImport("imm32.dll")]
        public static extern bool ImmGetOpenStatus(IntPtr hIMC);

        public struct COPYDATASTRUCT
        {
            public IntPtr dwData;
            public int cbData;
            public IntPtr lpData;
        }

        /// <summary>
        /// 跨視窗傳送訊息
        /// </summary>
        /// <param name="FormName"></param>
        /// <param name="Message"></param>
        public static void SendMessage(string FormName, string Message)
        {
            IntPtr hWnd = FindWindow(null, FormName);
            if (!hWnd.Equals(IntPtr.Zero))
            {
                int length = Encoding.UTF8.GetByteCount(Message);
                COPYDATASTRUCT cd = new COPYDATASTRUCT();
                cd.dwData = IntPtr.Zero;
                cd.cbData = length + 1;
                cd.lpData = Marshal.StringToHGlobalAnsi(Message);
                SendMessage(hWnd, WM_COPYDATA, 0, ref cd);
            }
        }

        /// <summary>
        /// 格式化傳送訊息
        /// </summary>
        /// <param name="SendName">自己的名稱</param>
        /// <param name="SendPORT">自己的 PORT</param>
        /// <param name="SendIP">自己的 IP</param>
        /// <param name="ReciveName">接收者的名稱</param>
        /// <param name="Message">訊息</param>
        /// <returns></returns>
        public static byte[] GetMessageBytes(string SendName, string SendIP, string SendPORT, string ReciveName, string Message)
        {
            string sendTemp = string.Format("SendName={0}SendIP={1}SendPORT={2}ReciveName={3}Message={4}",
                SendName + chrStep,
                SendIP + chrStep,
                SendPORT + chrStep,
                ReciveName + chrStep,
                Message);

            byte[] sendBuffer = Encoding.UTF8.GetBytes(sendTemp);
            return sendBuffer;
        }

        /// <summary>
        /// 格式化傳送檔案要求訊息
        /// </summary>
        /// <param name="SendName">自己的名稱</param>
        /// <param name="SendPORT">自己的 PORT</param>
        /// <param name="SendIP">自己的 IP</param>
        /// <param name="FileName">檔案名稱</param>
        /// <param name="FileLength">檔案大小</param>
        /// <returns></returns>
        public static byte[] GetSendFileActBytes(string SendName, string SendIP, string SendPORT, string FileName, string FileLength)
        {
            string sendTemp = string.Format("SendName={0}SendIP={1}SendPORT={2}Message={3}FileName={4}FileLength={5}",
                SendName + chrStep,
                SendIP + chrStep,
                SendPORT + chrStep,
                "SendFile" + chrStep,
                FileName + chrStep,
                FileLength + chrStep);

            byte[] sendBuffer = Encoding.UTF8.GetBytes(sendTemp);
            return sendBuffer;
        }

        /// <summary>
        /// 取得接收訊息陣列
        /// </summary>
        /// <param name="readBuffer"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public static string[] GetReciveMessage(byte[] readBuffer, int length)
        {
            string readTemp = Encoding.UTF8.GetString(readBuffer, 0, length);
            string[] readArray = readTemp.Split(chrStep);
            return readArray;
        }

        /// <summary>
        /// 從 readBuffer 取得接收資料實際大小的陣列
        /// </summary>
        /// <param name="readBuffer"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public static byte[] GetReciveBytes(byte[] readBuffer, int length)
        {
            byte[] output = new byte[length];

            for (int i = 0; i < length; i++)
            {
                output[i] = readBuffer[i];
            }

            return output;
        }

        /// <summary>
        /// 以 key 值取出傳入參數的值
        /// </summary>
        /// <param name="args"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string FindArrayValue(string[] args, string key)
        {
            string strReturnValue = "";
            foreach (string s in args)
            {
                if (s.IndexOf(key) > -1)
                {
                    if (s.IndexOf('=') > -1)
                    {
                        strReturnValue = s.Substring(s.IndexOf('=') + 1, s.Length - (s.IndexOf('=') + 1));
                        break;
                    }
                }
            }
            return strReturnValue;
        }

        /// <summary>
        /// 取得聊天視窗狀態
        /// </summary>
        /// <param name="appName">視窗 Title</param>
        /// <returns>true:開啟/false:未開啟</returns>
        public static bool GetMessageFormStatus(string formName)
        {
            bool bResult = false;
            Process[] myProcess = Process.GetProcessesByName("MessageForm");

            foreach (Process proc in myProcess)
            {
                if (proc.MainWindowTitle.Equals(formName))
                {
                    bResult = true;
                    break;
                }
            }

            return bResult;
        }
    }

    /// <summary>
    /// 聯絡人聊天視窗資訊
    /// </summary>
    public class FormList
    {
        public FormList(string formName, string ip, int port, string status)
        {
            FormName = formName;
            IP = ip;
            PORT = port;
            Status = status;
        }
        public string FormName { get; set; }
        public string IP { get; set; }
        public int PORT { get; set; }
        public string Status { get; set; }
    }

    /// <summary>
    /// 表情符號代碼
    /// </summary>
    public class FaceCode
    {
        public FaceCode(string code, string file)
        {
            Code = code;
            File = file;
        }
        public string Code { get; set; }
        public string File { get; set; }
    }
}
