﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace UtilityTools
{
    public class LogFile
    {
        private string strFilePath = Application.StartupPath + "\\ChatLog";
        private string strFileName;

        public LogFile() 
        {
            strFilePath += "\\" + DateTime.Now.ToString("yyyyMMdd");

            if (!Directory.Exists(strFilePath))
            {
                Directory.CreateDirectory(strFilePath);
            }
        }

        //建立Log檔
        private void CreateFile(string stream)
        {
            if (File.Exists(strFilePath + "\\" + strFileName)) return;
            StreamWriter sw = File.AppendText(strFilePath + "\\" + strFileName);
            sw.WriteLine(stream);
            sw.Close();
        }


        private void WriteStream(string stream, string filename)
        {
            strFileName = filename + ".log";
            if (!File.Exists(strFilePath + "\\" + strFileName))
                CreateFile(stream);
            else
            {
                StreamWriter sw = File.AppendText(strFilePath + "\\" + strFileName);
                sw.WriteLine(stream);
                sw.Close();
            }
        }

        public bool WriteToLog(string LogText, string ContactName)
        {
            bool ret;
            try
            {
                WriteStream(LogText, ContactName);
                ret = true;
            }
            catch
            {
                ret = false;
            }
            return ret;
        }
    }

}
