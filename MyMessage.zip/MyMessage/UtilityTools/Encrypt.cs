﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace UtilityTools
{
    public class EncryptTools
    {
        public static byte[] Encrypt(string strContent, string strPwd)
        {
            byte[] byteContent = Encoding.UTF8.GetBytes(strContent);

            byte[] output = Encrypt(byteContent, strPwd);

            return output;
        }

        public static byte[] Encrypt(byte[] byteContent, string strPwd)
        {
            byte[] bytePwd = Encoding.UTF8.GetBytes(strPwd);

            //使用 MD5 將加密密碼轉成固定長度
            MD5CryptoServiceProvider MD5Provider = new MD5CryptoServiceProvider();
            byte[] bytePwdMD5 = MD5Provider.ComputeHash(bytePwd);

            //產生加密實體
            RijndaelManaged AESProvider = new RijndaelManaged();
            ICryptoTransform AESEncrypt = AESProvider.CreateEncryptor(bytePwdMD5, bytePwdMD5);

            byte[] output = AESEncrypt.TransformFinalBlock(byteContent, 0, byteContent.Length);
            return output;
        }

        public static string Decrypt(byte[] byteContent, string strPwd)
        {
            byte[] bytePwd = Encoding.UTF8.GetBytes(strPwd);

            //使用 MD5 將加密密碼轉成固定長度
            MD5CryptoServiceProvider MD5Provider = new MD5CryptoServiceProvider();
            byte[] bytePwdMD5 = MD5Provider.ComputeHash(bytePwd);

            //產生解密實體
            RijndaelManaged AESProvider = new RijndaelManaged();
            ICryptoTransform AESDecrypt = AESProvider.CreateDecryptor(bytePwdMD5, bytePwdMD5);

            byte[] byteOutput = AESDecrypt.TransformFinalBlock(byteContent, 0, byteContent.Length);
            return Encoding.UTF8.GetString(byteOutput);
        }
    }
}
