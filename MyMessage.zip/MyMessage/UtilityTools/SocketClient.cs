﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace UtilityTools
{
    public class SocketClient
    {
        private string SendIP;
        private int SendPORT;

        public SocketClient(string IP, int PORT)
        {
            SendIP = IP;
            SendPORT = PORT;
        }

        public string Send(byte[] sendBuffer)
        {
            string data = "";
            try
            {
                TcpClient client = new TcpClient();
                IAsyncResult myResult = client.BeginConnect(SendIP, SendPORT, null, null);
                myResult.AsyncWaitHandle.WaitOne(1000, true);

                if (myResult.IsCompleted)
                {
                    NetworkStream stream = client.GetStream();

                    try
                    {
                        stream.Write(sendBuffer, 0, sendBuffer.Length);
                        byte[] readBuffer = new byte[client.ReceiveBufferSize];
                        int bytesRead = stream.Read(readBuffer, 0, readBuffer.Length);
                        data = Encoding.UTF8.GetString(readBuffer, 0, bytesRead);
                    }
                    catch (SocketException se)
                    {
                        data = se.Message;
                    }
                    catch (Exception ex)
                    {
                        data = ex.Message;
                    }
                    stream.Close();
                    client.Close();
                }
                else
                {
                    client.Close();
                    data = "聯絡人不在線上!!";
                }
            }
            catch (Exception ex)
            {
                data = ex.Message;
            }

            return data;
        }
    }
}
