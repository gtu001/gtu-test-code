﻿namespace MessageForm
{
    partial class FormMessage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMessage));
            this.tboxInput = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.AddContactToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tboxShow = new System.Windows.Forms.RichTextBox();
            this.panFace = new System.Windows.Forms.Panel();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.labFace = new System.Windows.Forms.Label();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.labFont = new System.Windows.Forms.Label();
            this.TransFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panFace.SuspendLayout();
            this.SuspendLayout();
            // 
            // tboxInput
            // 
            this.tboxInput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tboxInput.Location = new System.Drawing.Point(12, 327);
            this.tboxInput.MaxLength = 1000;
            this.tboxInput.Multiline = true;
            this.tboxInput.Name = "tboxInput";
            this.tboxInput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tboxInput.Size = new System.Drawing.Size(422, 82);
            this.tboxInput.TabIndex = 1;
            this.tboxInput.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tboxInput_KeyUp);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddContactToolStripMenuItem,
            this.TransFileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(447, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // AddContactToolStripMenuItem
            // 
            this.AddContactToolStripMenuItem.Name = "AddContactToolStripMenuItem";
            this.AddContactToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.AddContactToolStripMenuItem.Text = "加入對話";
            this.AddContactToolStripMenuItem.Click += new System.EventHandler(this.AddContactToolStripMenuItem_Click);
            // 
            // tboxShow
            // 
            this.tboxShow.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tboxShow.BackColor = System.Drawing.Color.White;
            this.tboxShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.tboxShow.Location = new System.Drawing.Point(12, 27);
            this.tboxShow.Name = "tboxShow";
            this.tboxShow.ReadOnly = true;
            this.tboxShow.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.tboxShow.Size = new System.Drawing.Size(423, 294);
            this.tboxShow.TabIndex = 3;
            this.tboxShow.Text = "";
            // 
            // panFace
            // 
            this.panFace.BackColor = System.Drawing.Color.White;
            this.panFace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panFace.Controls.Add(this.button13);
            this.panFace.Controls.Add(this.button12);
            this.panFace.Controls.Add(this.button11);
            this.panFace.Controls.Add(this.button10);
            this.panFace.Controls.Add(this.button9);
            this.panFace.Controls.Add(this.button8);
            this.panFace.Controls.Add(this.button7);
            this.panFace.Controls.Add(this.button6);
            this.panFace.Controls.Add(this.button5);
            this.panFace.Controls.Add(this.button4);
            this.panFace.Controls.Add(this.button3);
            this.panFace.Controls.Add(this.button2);
            this.panFace.Controls.Add(this.button1);
            this.panFace.Location = new System.Drawing.Point(12, 346);
            this.panFace.Name = "panFace";
            this.panFace.Size = new System.Drawing.Size(182, 63);
            this.panFace.TabIndex = 4;
            this.panFace.Visible = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.SystemColors.Control;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Image = global::MessageForm.Properties.Resources.Img13;
            this.button13.Location = new System.Drawing.Point(128, 32);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(20, 20);
            this.button13.TabIndex = 12;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.Control;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Image = global::MessageForm.Properties.Resources.Img12;
            this.button12.Location = new System.Drawing.Point(103, 32);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(20, 20);
            this.button12.TabIndex = 11;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.Control;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Image = global::MessageForm.Properties.Resources.Img11;
            this.button11.Location = new System.Drawing.Point(79, 32);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(20, 20);
            this.button11.TabIndex = 10;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.Control;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Image = global::MessageForm.Properties.Resources.Img10;
            this.button10.Location = new System.Drawing.Point(54, 32);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(20, 20);
            this.button10.TabIndex = 9;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.Control;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Image = global::MessageForm.Properties.Resources.Img9;
            this.button9.Location = new System.Drawing.Point(29, 32);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(20, 20);
            this.button9.TabIndex = 8;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.Control;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Image = global::MessageForm.Properties.Resources.Img8;
            this.button8.Location = new System.Drawing.Point(4, 32);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(20, 20);
            this.button8.TabIndex = 7;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.Control;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Image = global::MessageForm.Properties.Resources.Img7;
            this.button7.Location = new System.Drawing.Point(153, 4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(20, 20);
            this.button7.TabIndex = 6;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Control;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Image = global::MessageForm.Properties.Resources.Img6;
            this.button6.Location = new System.Drawing.Point(127, 4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(20, 20);
            this.button6.TabIndex = 5;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Image = global::MessageForm.Properties.Resources.Img5;
            this.button5.Location = new System.Drawing.Point(102, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(20, 20);
            this.button5.TabIndex = 4;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Control;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Image = global::MessageForm.Properties.Resources.Img4;
            this.button4.Location = new System.Drawing.Point(78, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(20, 20);
            this.button4.TabIndex = 3;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = global::MessageForm.Properties.Resources.Img3;
            this.button3.Location = new System.Drawing.Point(54, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(20, 20);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Control;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = global::MessageForm.Properties.Resources.Img2;
            this.button2.Location = new System.Drawing.Point(29, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(20, 20);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = global::MessageForm.Properties.Resources.Img1;
            this.button1.Location = new System.Drawing.Point(4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(20, 20);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // labFace
            // 
            this.labFace.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labFace.AutoSize = true;
            this.labFace.Location = new System.Drawing.Point(12, 414);
            this.labFace.Name = "labFace";
            this.labFace.Size = new System.Drawing.Size(55, 13);
            this.labFace.TabIndex = 5;
            this.labFace.Text = "表情符號";
            this.labFace.Click += new System.EventHandler(this.labFace_Click);
            // 
            // fontDialog1
            // 
            this.fontDialog1.AllowScriptChange = false;
            this.fontDialog1.ShowColor = true;
            // 
            // labFont
            // 
            this.labFont.AutoSize = true;
            this.labFont.Location = new System.Drawing.Point(74, 413);
            this.labFont.Name = "labFont";
            this.labFont.Size = new System.Drawing.Size(55, 13);
            this.labFont.TabIndex = 6;
            this.labFont.Text = "設定字型";
            this.labFont.Visible = false;
            this.labFont.Click += new System.EventHandler(this.labFont_Click);
            // 
            // TransFileToolStripMenuItem
            // 
            this.TransFileToolStripMenuItem.Name = "TransFileToolStripMenuItem";
            this.TransFileToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.TransFileToolStripMenuItem.Text = "傳送檔案";
            this.TransFileToolStripMenuItem.Click += new System.EventHandler(this.TransFileToolStripMenuItem_Click);
            // 
            // FormMessage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(447, 430);
            this.Controls.Add(this.labFont);
            this.Controls.Add(this.labFace);
            this.Controls.Add(this.panFace);
            this.Controls.Add(this.tboxShow);
            this.Controls.Add(this.tboxInput);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormMessage";
            this.Text = "FormMessage";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMessage_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panFace.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tboxInput;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem AddContactToolStripMenuItem;
        private System.Windows.Forms.RichTextBox tboxShow;
        private System.Windows.Forms.Panel panFace;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label labFace;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.Label labFont;
        private System.Windows.Forms.ToolStripMenuItem TransFileToolStripMenuItem;
    }
}