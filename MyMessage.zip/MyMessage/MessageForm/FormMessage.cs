﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Data;
using System.IO;
using UtilityTools;

namespace MessageForm
{
    //委派 AddMessage
    public delegate void AddMsgCallBack(string msg);

    public partial class FormMessage : Form
    {
        #region 成員宣告
        private string ContactName;     //聯絡人名稱
        private string ContactIP;       //聯絡人 IP
        private string ContactPORT;     //聯絡人 PORT
        private string MyName;          //自己的名稱
        private string MyIP;            //自己的 IP
        private string MyPORT;          //自己的 PORT
        private string strStep = "^";   //分隔符號
        private LogFile log;            //Log物件
        private List<FaceCode> listFace;  //表情符號
        private DataTable dtFont;

        public List<FormList> listConnContract = new List<FormList>();
        #endregion

        public string FormName { get { return MyName; } }
        public string IP { get { return MyIP; } }
        public string PORT { get { return MyPORT; } }

        #region 建構函式
        /// <summary>
        /// 建構函式
        /// </summary>
        /// <param name="args">傳入參數</param>
        public FormMessage(string[] args)
        {
            InitializeComponent();
            SetArguments(args);
            this.Text = ContactName;
            log = new LogFile();
            CreateFaceCode();
        }
        #endregion

        #region 事件

        /// <summary>
        /// 視窗被啟用及設定焦點
        /// </summary>
        /// <param name="e"></param>
        protected override void OnActivated(EventArgs e)
        {
            tboxInput.Focus();
            base.OnActivated(e);
        }

        /// <summary>
        /// 視窗關閉
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormMessage_FormClosing(object sender, FormClosingEventArgs e)
        {
            //傳送訊息給主程式，告知此視窗關閉
            //Utility.SendMessage("MyMessage", this.Text);
        }

        /// <summary>
        /// 按下 Enter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tboxInput_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyValue.Equals(13) && e.Shift != true)
            {
                if (tboxInput.Text.Trim(new char[] { '\r', '\n' }) != "")
                {
                    string msg = tboxInput.Text.Trim(new char[] { '\r', '\n' });
                    tboxInput.Text = "";
                    AddMessage(MyName + strStep + msg);
                    SendMessage(msg);
                }
                else
                {
                    tboxInput.Text = "";
                }
            }
        }

        /// <summary>
        /// 表情符號 panel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void labFace_Click(object sender, EventArgs e)
        {
            panFace.Visible = !panFace.Visible;
        }

        /// <summary>
        /// FontDialog
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void labFont_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                DataSet ds = new DataSet();
                ds.ReadXml(Application.StartupPath + "\\setting.xml");
                ds.Tables.Remove("Font");

                dtFont = Utility.CreateFontTable();
                DataRow dr = dtFont.NewRow();
                Font font = fontDialog1.Font;
                dr["FontFamily"] = font.FontFamily.Name;
                dr["Size"] = font.Size.ToString();
                dr["Style"] = font.Style.ToString();
                dr["Color"] = fontDialog1.Color.Name;
                dtFont.Rows.Add(dr);
                ds.Tables.Add(dtFont);
                ds.WriteXml(Application.StartupPath + "\\setting.xml");
            }
        }

        /// <summary>
        /// 按下表情符號
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImageButton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string strCode = SearchFaceCode(btn.Name);
            tboxInput.AppendText(strCode);
            tboxInput.Focus();
            panFace.Visible = false;
        }

        #endregion

        #region 私有方法
        /// <summary>
        /// 將傳入的參數設定給成員變數
        /// </summary>
        /// <param name="args"></param>
        private void SetArguments(string[] args)
        {
            #region 此聊天視窗的基本資料
            ContactName = Utility.FindArrayValue(args, "ContactName");
            ContactIP = Utility.FindArrayValue(args, "ContactIP");
            ContactPORT = Utility.FindArrayValue(args, "ContactPORT");
            if (ContactName.IndexOf(",") >= 0)
            {
                string[] arrName = ContactName.Split(new char[] { ',' });
                string[] arrIP = ContactIP.Split(new char[] { ',' });
                string[] arrPORT = ContactPORT.Split(new char[] { ',' });
                for (int i = 0; i < arrName.Length; i++)
                {
                    listConnContract.Add(new FormList(arrName[i], arrIP[i], int.Parse(arrPORT[i]), ""));
                }
            }
            else
            {
                listConnContract.Add(new FormList(ContactName, ContactIP, int.Parse(ContactPORT), ""));
            }
            
            #endregion

            #region 自己的基本資料
            MyIP = Utility.FindArrayValue(args, "SendIP");
            MyName = Utility.FindArrayValue(args, "SendName");
            MyPORT = Utility.FindArrayValue(args, "SendPORT");
            #endregion

        }

        /// <summary>
        /// 建立表情符號清單
        /// </summary>
        private void CreateFaceCode()
        {
            string strPath = Application.StartupPath + "\\Face\\";
            listFace = new List<FaceCode>();
            listFace.Add(new FaceCode(":)", strPath + "Img1.png"));
            listFace.Add(new FaceCode(":D", strPath + "Img2.png"));
            listFace.Add(new FaceCode(":d", strPath + "Img2.png"));
            listFace.Add(new FaceCode(":(", strPath + "Img3.png"));
            listFace.Add(new FaceCode(":@", strPath + "Img4.png"));
            listFace.Add(new FaceCode(":|", strPath + "Img5.png"));
            listFace.Add(new FaceCode(":O", strPath + "Img6.png"));
            listFace.Add(new FaceCode(":o", strPath + "Img6.png"));
            listFace.Add(new FaceCode(":$", strPath + "Img7.png"));
            listFace.Add(new FaceCode(":P", strPath + "Img8.png"));
            listFace.Add(new FaceCode(":p", strPath + "Img8.png"));
            listFace.Add(new FaceCode(":S", strPath + "Img9.png"));
            listFace.Add(new FaceCode(":s", strPath + "Img9.png"));
            listFace.Add(new FaceCode(";)", strPath + "Img10.png"));
            listFace.Add(new FaceCode("^O)", strPath + "Img11.png"));
            listFace.Add(new FaceCode("^o)", strPath + "Img11.png"));
            listFace.Add(new FaceCode("XD", strPath + "Img12.png"));
            listFace.Add(new FaceCode("xd", strPath + "Img12.png"));
            listFace.Add(new FaceCode("Xd", strPath + "Img12.png"));
            listFace.Add(new FaceCode("xD", strPath + "Img12.png"));
            listFace.Add(new FaceCode(":'(", strPath + "Img13.png"));
        }

        /// <summary>
        /// 取得表情符號
        /// </summary>
        /// <param name="btnName"></param>
        /// <returns></returns>
        private string SearchFaceCode(string btnName)
        {
            string strCode = "";
            string id = btnName.Replace("button", "");
            FaceCode code = listFace.Find(u => u.File.LastIndexOf("Img" + id) > -1);
            strCode = code.Code;
            return strCode;
        }

        /// <summary>
        /// 傳送訊息
        /// </summary>
        /// <param name="msg"></param>
        private void SendMessage(string msg)
        {
            string sendName = "";
            string sendIP = "";
            string sendPORT = "";

            if (listConnContract.Count > 1)
            {   //多人對談
                foreach (FormList frm in listConnContract)
                {
                    sendName += frm.FormName + ",";
                    sendIP += frm.IP + ",";
                    sendPORT += frm.PORT + ",";
                }

                sendName = sendName.Substring(0, sendName.Length - 1);
                sendIP = sendIP.Substring(0, sendIP.Length - 1);
                sendPORT = sendPORT.Substring(0, sendPORT.Length - 1);

                foreach (FormList frm in listConnContract)
                {
                    if (frm.IP == MyIP) continue;
                    //建立接收端
                    SocketClient client = new SocketClient(frm.IP, frm.PORT);
                    byte[] sendBuffer = Utility.GetMessageBytes(sendName, sendIP, sendPORT, frm.FormName, msg);
                    string data = client.Send(EncryptTools.Encrypt(sendBuffer, Utility.EncryptPwd));
                    if (data != "0")
                    {
                        AddMessage("系統訊息" + strStep + data);
                    }
                }
            }
            else
            {
                //建立接收端
                FormList frm = listConnContract[0];
                SocketClient client = new SocketClient(frm.IP, frm.PORT);
                byte[] sendBuffer = Utility.GetMessageBytes(MyName, MyIP, MyPORT, frm.FormName, msg);
                string data = client.Send(EncryptTools.Encrypt(sendBuffer, Utility.EncryptPwd));
                if (data != "0")
                {
                    AddMessage("系統訊息" + strStep + data);
                }
            }
        }


        /// <summary>
        /// 新增對話聯絡人
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddContactToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormContact frmContact = new FormContact();
            if (frmContact.ShowDialog(this) == DialogResult.OK)
            {
                string strFormTitle = "";
                foreach (FormList frm in listConnContract)
                {
                    strFormTitle += frm.FormName + ",";
                }
                this.Text = strFormTitle.Substring(0, strFormTitle.Length - 1);
            }

            if (listConnContract.Count > 1)
            {
                if (!listConnContract.Exists(u => u.FormName == MyName))
                {
                    listConnContract.Add(new FormList(MyName, MyIP, int.Parse(MyPORT), ""));
                    this.Text += "," + MyName;
                }
            }
        }

        /// <summary>
        /// Append 時間及發言人
        /// </summary>
        /// <param name="msg"></param>
        private void AppendTitleText(string msg)
        {
            tboxShow.AppendText(msg);
            int iStart = tboxShow.Text.IndexOf(msg);
            int iEnd = msg.Length;
            tboxShow.Select(iStart, iEnd);
            tboxShow.SelectionColor = Color.Gray;
            tboxShow.Refresh();
            tboxShow.AppendText(Environment.NewLine);
        }

        /// <summary>
        /// Append 訊息內容
        /// </summary>
        /// <param name="msg"></param>
        private void AppendContectText(string msg)
        {
            string strTemp = msg;
            bool bHasFaceCode = false;
            foreach (FaceCode code in listFace)
            {
                int iIndex = strTemp.IndexOf(code.Code);
                if (iIndex > -1)
                {
                    bHasFaceCode = true;
                    string t = "";
                    if (iIndex > 0)
                    {
                        t = strTemp.Substring(0, iIndex);
                        tboxShow.AppendText(t);
                    }
                    DrawImageToTextBox(code.File);
                    strTemp = strTemp.Replace(t + code.Code, "");
                    AppendContectText(strTemp);
                    if (bHasFaceCode) break;
                }
            }

            if (!bHasFaceCode && strTemp != "")
                tboxShow.AppendText(strTemp);

        }

        /// <summary>
        /// 顯示表情符號
        /// </summary>
        /// <param name="file"></param>
        private void DrawImageToTextBox(string file)
        {
            Clipboard.Clear();
            Clipboard.SetDataObject(Image.FromFile(file), false);
            tboxShow.ReadOnly = false;
            tboxShow.Paste();
            tboxShow.ReadOnly = true;
            Clipboard.Clear();
        }
        #endregion

        #region 公有方法
        /// <summary>
        /// 將訊息送到 tboxShow
        /// </summary>
        /// <param name="msg"></param>
        public void AddMessage(string msg)
        {
            if (tboxShow.InvokeRequired)
                tboxShow.Invoke(new AddMsgCallBack(this.AddMessage), msg);
            else
            {
                string name = msg.Substring(0, msg.IndexOf(strStep));
                string message = msg.Replace(name + strStep, "");
                string strTime = "[" + DateTime.Now.ToString("HH:mm:ss") + "]";
                AppendTitleText(strTime + "  " + name + "：");
                AppendContectText(message);
                tboxShow.AppendText(Environment.NewLine);
                tboxShow.AppendText(Environment.NewLine);

                log.WriteToLog(strTime + "  " + name + "：", this.Text);
                log.WriteToLog(message + "\r\n", this.Text);
                tboxShow.ScrollToCaret();
                this.Activate();
            }
        }
        #endregion

        #region 覆寫方法
        /// <summary>
        /// 接收 Window 訊息
        /// </summary>
        /// <param name="m"></param>
        protected override void DefWndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case Utility.WM_COPYDATA:
                    Utility.COPYDATASTRUCT cd = new Utility.COPYDATASTRUCT();
                    Type cdType = cd.GetType();
                    cd = (Utility.COPYDATASTRUCT)m.GetLParam(cdType);
                    string msg = Marshal.PtrToStringAnsi(cd.lpData);
                    AddMessage(msg);
                    break;

                default:
                    base.DefWndProc(ref m);
                    break;
            }
        }
        #endregion

        private void TransFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listConnContract.Count > 1)
            {
                MessageBox.Show("只有單人對談才可以傳送檔案!");
                return;
            }

            OpenFileDialog fileDiaLog = new OpenFileDialog();
            if (fileDiaLog.ShowDialog() != DialogResult.OK) return;

            Stream fileStream = fileDiaLog.OpenFile();  //檔案資料流
            string strFileName = fileDiaLog.FileName;   //檔名
            long lFileLength = fileStream.Length;       //檔案大小
            strFileName = strFileName.Substring(strFileName.LastIndexOf("\\") + 1);

            //建立接收端
            FormList frm = listConnContract[0];
            SocketClient client = new SocketClient(frm.IP, frm.PORT);
            byte[] sendBuffer = Utility.GetSendFileActBytes(MyName, MyIP, MyPORT, strFileName, lFileLength.ToString());
            string data = client.Send(EncryptTools.Encrypt(sendBuffer, Utility.EncryptPwd));
            if (data == "0")
            {
                MessageBox.Show("對方同意接收檔案");
            }
            else
            {
                MessageBox.Show(data);
            }
        }

    }
}
