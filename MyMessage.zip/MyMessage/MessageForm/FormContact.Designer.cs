﻿namespace MessageForm
{
    partial class FormContact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxContact = new System.Windows.Forms.ListBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBoxContact
            // 
            this.listBoxContact.CausesValidation = false;
            this.listBoxContact.FormattingEnabled = true;
            this.listBoxContact.Location = new System.Drawing.Point(13, 13);
            this.listBoxContact.MultiColumn = true;
            this.listBoxContact.Name = "listBoxContact";
            this.listBoxContact.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBoxContact.Size = new System.Drawing.Size(259, 212);
            this.listBoxContact.TabIndex = 0;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(196, 232);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "加入";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // FormContact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.listBoxContact);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormContact";
            this.ShowInTaskbar = false;
            this.Text = "聯絡人清單";
            this.Shown += new System.EventHandler(this.FormContact_Shown);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxContact;
        private System.Windows.Forms.Button btnAdd;
    }
}