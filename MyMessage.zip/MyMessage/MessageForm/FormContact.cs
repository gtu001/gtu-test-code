﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UtilityTools;

namespace MessageForm
{
    public partial class FormContact : Form
    {
        string strContactXml = Application.StartupPath + "\\Contact.xml";
        DataTable dtContact = new DataTable();
        FormMessage owForm;

        public FormContact()
        {
            InitializeComponent();
        }

        private void LoadContact()
        {
            owForm = (FormMessage)this.Owner;
            dtContact = Utility.CreateContractTable();
            dtContact.ReadXml(strContactXml);

            foreach (DataRow dr in dtContact.Rows)
            {
                SocketClient client = new SocketClient(dr["IP"].ToString(), int.Parse(dr["PORT"].ToString()));
                byte[] sendBuffer = Utility.GetMessageBytes(owForm.FormName,
                                                            owForm.IP,
                                                            owForm.PORT.ToString(),
                                                            dr["NickName"].ToString(),
                                                            "1");
                string data = client.Send(EncryptTools.Encrypt(sendBuffer, Utility.EncryptPwd));
                if (data == "0")
                {
                    if (!owForm.listConnContract.Exists(u => u.FormName == dr["NickName"].ToString()))
                        listBoxContact.Items.Add(dr["NickName"].ToString());
                        
                }
            }
            

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            foreach (string item in listBoxContact.SelectedItems)
            {
                DataRow[] dr = dtContact.Select("NickName='" + item + "'");
                owForm.listConnContract.Add(new FormList(dr[0]["NickName"].ToString(),
                                                         dr[0]["IP"].ToString(),
                                                         int.Parse(dr[0]["PORT"].ToString()),
                                                         ""));
            }
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void FormContact_Shown(object sender, EventArgs e)
        {
            LoadContact();
        }
    }
}
