﻿using System;
using System.Data;
using System.Windows.Forms;
using UtilityTools;

namespace MyMessage
{
    public partial class FormSetting : Form
    {
        string strSettingXml = Application.StartupPath + "\\setting.xml";

        public FormSetting()
        {
            InitializeComponent();
            LoadSetting();
        }

        /// <summary>
        /// 載入設定
        /// </summary>
        private void LoadSetting()
        {
            if (System.IO.File.Exists(strSettingXml))
            {
                DataSet ds = new DataSet();
                DataTable dt;
                ds.ReadXml(strSettingXml);
                if (ds.Tables["Contract"].Rows.Count > 0)
                {
                    dt = ds.Tables["Contract"];
                    tboxNickName.Text = dt.Rows[0]["NickName"].ToString();
                    tboxIP.Text = dt.Rows[0]["IP"].ToString();
                    tboxPORT.Text = dt.Rows[0]["PORT"].ToString();
                }
            }
        }

        /// <summary>
        /// 儲存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {

            if (!Validate()) return;
            try
            {
                DataSet ds = new DataSet();
                ds.ReadXml(strSettingXml);
                if (ds.Tables.Contains("Contract"))
                    ds.Tables.Remove("Contract");

                DataTable dt = Utility.CreateContractTable();
                DataRow dr = dt.NewRow();
                dr["NickName"] = tboxNickName.Text;
                dr["IP"] = tboxIP.Text;
                dr["PORT"] = tboxPORT.Text;
                dt.Rows.Add(dr);
                ds.Tables.Add(dt);
                ds.WriteXml(strSettingXml);
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Close();
            }
        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 驗證
        /// </summary>
        /// <returns></returns>
        private bool Validate()
        {
            if (tboxNickName.Text == "")
            {
                MessageBox.Show("請輸入暱稱");
                return false;
            }

            if (tboxIP.Text == "")
            {
                MessageBox.Show("請輸入 IP");
                return false;
            }

            if (tboxPORT.Text == "")
            {
                MessageBox.Show("請輸入 PORT 號");
                return false;
            }

            return true;
        }
    }
}
