﻿using System;
using System.Data;
using System.Windows.Forms;
using UtilityTools;

namespace MyMessage
{
    public partial class FormContact : Form
    {
        string strContactxml = Application.StartupPath + "\\Contact.xml";
        DataTable dt;

        public FormContact()
        {
            InitializeComponent();
            LoadContact();
        }

        /// <summary>
        /// 載入聯絡人
        /// </summary>
        private void LoadContact()
        {
            dt = Utility.CreateContractTable();
            if (System.IO.File.Exists(strContactxml))
            {
                dt.ReadXml(strContactxml);
            }
        }

        /// <summary>
        /// 儲存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!Validate()) return;
            try
            {
                DataRow[] drs;
                drs = dt.Select("NickName='" + tboxNickName.Text + "'");
                if (drs.Length > 0)
                {
                    MessageBox.Show("暱稱重覆!請重新輸入");
                    tboxNickName.Focus();
                    return;
                }

                drs = dt.Select("IP='" + tboxIP.Text + "'");
                if (drs.Length > 0)
                {
                    MessageBox.Show("IP重覆!請重新輸入");
                    tboxIP.Focus();
                    return;
                }

                DataRow dr = dt.NewRow();
                dr["NickName"] = tboxNickName.Text;
                dr["IP"] = tboxIP.Text;
                dr["PORT"] = tboxPORT.Text;
                dt.Rows.Add(dr);
                dt.WriteXml(strContactxml, true);
                this.DialogResult = DialogResult.OK;
                this.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                this.Close();
            }
        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 驗證
        /// </summary>
        /// <returns></returns>
        private bool Validate()
        {
            if (tboxNickName.Text == "")
            {
                MessageBox.Show("請輸入暱稱");
                return false;
            }

            if (tboxIP.Text == "")
            {
                MessageBox.Show("請輸入 IP");
                return false;
            }

            if (tboxPORT.Text == "")
            {
                MessageBox.Show("請輸入 PORT 號");
                return false;
            }

            return true;
        }

    }
}
