﻿using System;
using System.Data;
using System.Text;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Threading;
using UtilityTools;

namespace MyMessage
{
    public class SocketServer
    {
        public TcpListener listenerServer;

        Form1 form1;    //主視窗執行個體

        public SocketServer(Form1 form)
        {
            form1 = form;
        }

        /// <summary>
        /// 監聽程序
        /// </summary>
        public void StartListener()
        {
            listenerServer = new TcpListener(form1.IP, form1.PORT);
            try
            {
                listenerServer.Start();
            }
            catch (Exception ex)
            {
                listenerServer.Stop();
                MessageBox.Show(ex.Message);
                return;
            }

            try
            {
                while (true)
                {
                    byte[] sendBuffer;  //傳送的位元組
                    byte[] readBuffer;  //接收的位元組
                    TcpClient client = listenerServer.AcceptTcpClient();
                    NetworkStream stream = client.GetStream();

                    try
                    {
                        try
                        {
                            readBuffer = new byte[client.ReceiveBufferSize];
                            int intRead = stream.Read(readBuffer, 0, client.ReceiveBufferSize);
                            byte[] byteRead = Utility.GetReciveBytes(readBuffer, intRead);
                            string data = ShowMessage(byteRead, intRead, client.Client.RemoteEndPoint);
                            //接收成功,回傳訊息
                            sendBuffer = Encoding.UTF8.GetBytes(data);
                        }
                        catch (SocketException se)
                        {
                            sendBuffer = Encoding.UTF8.GetBytes(se.Message);
                        }
                        catch (Exception ex)
                        {
                            sendBuffer = Encoding.UTF8.GetBytes(ex.Message);
                        }
                        stream.Write(sendBuffer, 0, sendBuffer.Length);
                    }
                    catch { }
                    client.Close();
                }
            }
            catch (ThreadAbortException ex)
            {
                
            }
        }

        /// <summary>
        /// 將接收到的訊息傳送到聊天視窗
        /// </summary>
        /// <param name="readBuffer"></param>
        /// <param name="length"></param>
        public string ShowMessage(byte[] readBuffer, int length, System.Net.EndPoint point)
        {
            string strReturnData = "";
            string strTemp = EncryptTools.Decrypt(readBuffer, Utility.EncryptPwd);//封包解密
            string[] arrTemp = strTemp.Split(Utility.chrStep);
            string SendName = Utility.FindArrayValue(arrTemp, "SendName");      //取得傳送者
            string SendIP = Utility.FindArrayValue(arrTemp, "SendIP");          //取得傳送者
            string SendPORT = Utility.FindArrayValue(arrTemp, "SendPORT");      //取得傳送者的 PORT
            string data = Utility.FindArrayValue(arrTemp, "Message");           //取得訊息

            //取得傳送者IP
            System.Net.IPEndPoint ipEP = (System.Net.IPEndPoint)point;
            string clientIP = ipEP.Address.ToString();

            switch (data)
            {
                case "1":
                case "2":
                    //更新聯絡人狀態 1:上線 2:下線
                    form1.UpdateContactStatus(clientIP, (data == "1") ? "Online" : "Offline");
                    form1.ReLoadContact();
                    strReturnData = "0";
                    break;
                case "SendFile":
                    //傳送檔案要求
                    strReturnData = ActSendFile(strTemp);
                    break;

                default:
                    if (SendName.IndexOf(",") < 0)//單人對談
                        ShowSigleTalk(SendName, SendIP, SendPORT, data);
                    else
                        ShowMultiTalk(SendName, SendIP, SendPORT, clientIP, data);

                    strReturnData = "0";
                    break;
            }

            return strReturnData;
        }

        /// <summary>
        /// 顯示單人對談視窗
        /// </summary>
        /// <param name="sendName">傳送者名稱</param>
        /// <param name="sendIP">傳送者 IP</param>
        /// <param name="sendPORT">傳送者 PORT</param>
        /// <param name="msg">訊息</param>
        private void ShowSigleTalk(string sendName, string sendIP, string sendPORT, string msg)
        {
            //先取出聯絡人資料
            FormList form = form1.listContact.Find(u => u.IP == sendIP);
            if (form != null)
            {   //視窗已開啟
                if (!Utility.GetMessageFormStatus(form.FormName))
                    ShowForm(form.FormName, form.IP, form.PORT.ToString());

                Utility.SendMessage(form.FormName, form.FormName + "^" + msg);
            }
            else
            {   //聯絡人不存在
                if (MessageBox.Show(sendName + " 不是你的聯絡人，是否加入聯絡人?", "提示訊息", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    form1.AddContact(sendName, sendIP, sendPORT);
                    ShowForm(sendName, sendIP, sendPORT);
                    Utility.SendMessage(sendName, sendName + "^" + msg);
                }
            }
        }

        /// <summary>
        /// 開啟多人對談視窗
        /// </summary>
        /// <param name="sendName">所有聯絡人名稱</param>
        /// <param name="sendIP">所有聯絡人 IP</param>
        /// <param name="sendPORT">所有聯絡人 PORT</param>
        /// <param name="clientIP">傳送者 IP</param>
        /// <param name="msg">訊息</param>
        private void ShowMultiTalk(string sendName, string sendIP, string sendPORT, string clientIP, string msg)
        {
            //檢查是否有不存在於聯絡人清單中的人
            string[] arrName = sendName.Split(',');
            string[] arrIP = sendIP.Split(',');
            string[] arrPORT = sendPORT.Split(',');
            for (int i = 0; i < arrName.Length; i++)
            {
                FormList frm = form1.listContact.Find(u => u.IP == arrIP[i]);
                if (frm == null)
                {
                    if (arrName[i] != form1.MyName)
                    {
                        form1.AddContact(arrName[i], arrIP[i], arrPORT[i]);
                    }
                }
            }


            //取出傳送者
            FormList form = form1.listContact.Find(u => u.IP == clientIP);
            //判斷視窗是否開啟
            if (!Utility.GetMessageFormStatus(sendName))
                ShowForm(sendName, sendIP, sendPORT);

            Utility.SendMessage(sendName, form.FormName + "^" + msg);
        }

        private string ActSendFile(string strMessage)
        {
            string strReturnData = "";
            string[] arrTemp = strMessage.Split(Utility.chrStep);
            string SendIP = Utility.FindArrayValue(arrTemp, "SendIP");
            string FileName = Utility.FindArrayValue(arrTemp, "FileName");
            string FileLength = Utility.FindArrayValue(arrTemp, "FileLength");
            FormList frm = form1.listContact.Find(u => u.IP == SendIP);
            string strMsg = string.Format("{0} 想要傳送 {1} 檔案給你，是否接受?", frm.FormName, FileName);
            if (MessageBox.Show(form1, strMsg, "提示訊息", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                strReturnData = "0";
            }
            else
            {
                strReturnData = "-1";
            }
            return strReturnData;
        }

        /// <summary>
        /// 開啟聊天視窗
        /// </summary>
        /// <param name="ContactName"></param>
        public void ShowForm(string ContactName, string ContactIP, string ContactPORT)
        {
            form1.ShowForm(ContactName, ContactIP, ContactPORT);
            while (true)
            {
                if (Utility.GetMessageFormStatus(ContactName))
                    break;
            }
        }

    }
}
