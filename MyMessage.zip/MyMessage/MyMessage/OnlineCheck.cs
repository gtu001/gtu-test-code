﻿using System;
using System.Data;
using System.Text;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Threading;
using UtilityTools;

namespace MyMessage
{
    public class OnlineCheck
    {
        Form1 form1;

        public OnlineCheck(Form1 form)
        {
            form1 = form;
        }

        /// <summary>
        /// 檢查聯絡人是否上線
        /// </summary>
        public void StartCheck()
        {
            if (form1.listContact.Count > 0)
            {
                SocketClient client;
                foreach (FormList form in form1.listContact)
                {
                    client = new SocketClient(form.IP, form.PORT);
                    byte[] sendBuffer = Utility.GetMessageBytes(
                        form1.dtSetting.Rows[0]["NickName"].ToString(),
                        form1.dtSetting.Rows[0]["IP"].ToString(),
                        form1.dtSetting.Rows[0]["PORT"].ToString(),
                        form.FormName,
                        "1");
                    string data = client.Send(EncryptTools.Encrypt(sendBuffer, Utility.EncryptPwd));

                    if (data == "0")
                    {
                        form1.UpdateContactStatus(form.IP, "Online");
                    }
                    else
                    {
                        form1.UpdateContactStatus(form.IP, "Offline");
                    }
                }
                form1.ReLoadContact();
            }
        }

        /// <summary>
        /// 通知自己的聯絡人自己下線了
        /// </summary>
        public void NoticeStatus()
        {
            SocketClient client;
            foreach (FormList form in form1.listContact)
            {
                client = new SocketClient(form.IP, form.PORT);
                byte[] sendBuffer = Utility.GetMessageBytes(
                    form1.dtSetting.Rows[0]["NickName"].ToString(),
                    form1.dtSetting.Rows[0]["IP"].ToString(),
                    form1.dtSetting.Rows[0]["PORT"].ToString(),
                    form.FormName,
                    "2");
                string data = client.Send(EncryptTools.Encrypt(sendBuffer, Utility.EncryptPwd));

            }
        }
    }
}
