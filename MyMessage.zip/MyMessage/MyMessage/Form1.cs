﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using System.Text;
using System.Drawing;
using UtilityTools;

namespace MyMessage
{
    public delegate void delegateAddContact(string name, string ip, string port);
    public delegate void delegateShowForm(string ContactName, string ContactIP, string ContactPORT);
    public delegate void delegateUpdateContactStatus(string ip, string status);
    public delegate void delegateReloadContactList();

    public partial class Form1 : Form
    {
        #region 成員宣告
        string strContactXml = Application.StartupPath + "\\Contact.xml";
        string strSettingXml = Application.StartupPath + "\\setting.xml";

        public DataTable dtContact;         //基本資料
        public DataTable dtSetting;         //聯絡人
        public IPAddress IP;                //自己的 IP
        public int PORT;                    //自己的 PORT
        public string MyName;               //自己的名稱
        public List<FormList> listContact = new List<FormList>();

        private Thread SocketThread;
        private SocketServer server;
        #endregion

        /// <summary>
        /// 建構函式
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            LoadContactList();  //載入聯絡人
            LoadSetting();      //載入設定檔

            #region 系統列圖示
            notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            notifyIcon1.Icon = new Icon("MyMessage.ico");
            notifyIcon1.Text = "MyMessage";
            notifyIcon1.MouseDoubleClick += new MouseEventHandler(notifyIcon1_MouseDoubleClick);
            notifyIcon1.MouseClick += new MouseEventHandler(notifyIcon1_MouseClick);
            #endregion

        }


        #region 事件
        /// <summary>
        /// 系統列圖示按二下顯示視窗
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
            notifyIcon1.Visible = false;
            this.WindowState = FormWindowState.Normal;
        }

        /// <summary>
        /// 系統列圖示按一下滑鼠右鍵
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {

            }
        }

        /// <summary>
        /// 主程式關閉時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                OfflineNotice();
            }
            catch { }

            Process[] myProcess = Process.GetProcessesByName("MessageForm");
            if (myProcess.Length > 0)
            {
                foreach (Process proc in myProcess)
                {
                    proc.Kill();    //關閉所有聊天視窗
                }
            }
        }

        /// <summary>
        /// 主程式視窗改變大小時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Hide();
                notifyIcon1.Visible = true;
            }
        }

        /// <summary>
        /// 開啟聯絡人聊天視窗
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gvContact_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string ContactName = gvContact.Rows[e.RowIndex].Cells[0].Value.ToString();
            //檢查聊天視窗是否已開啟
            bool IsExists = Utility.GetMessageFormStatus(ContactName);

            if (!IsExists)
            {
                FormList form = listContact.Find(u => u.FormName == ContactName);
                ShowForm(form.FormName, form.IP, form.PORT.ToString());
            }
        }

        #endregion

        #region Menu 事件
        /// <summary>
        /// 設定視窗
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SettingMenuItem_Click(object sender, EventArgs e)
        {
            FormSetting setting = new FormSetting();
            if (setting.ShowDialog() == DialogResult.OK)
            {
                LoadSetting();
            }
        }

        /// <summary>
        /// 新增聯絡人視窗
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ContactMenuItem_Click(object sender, EventArgs e)
        {
            FormContact contact = new FormContact();
            if (contact.ShowDialog() == DialogResult.OK)
            {
                LoadContactList();
                OnlineCheckStart();
            }
        }

        /// <summary>
        /// 更新聯絡人狀態
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ContactStatusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OnlineCheckStart();
        }

        #endregion

        #region 私有方法

        /// <summary>
        /// 載入聯絡人清單
        /// </summary>
        private void LoadContactList()
        {
            dtContact = Utility.CreateContractTable();
            if (System.IO.File.Exists(strContactXml))
            {
                dtContact.ReadXml(strContactXml);
                if (dtContact.Rows.Count > 0)
                {
                    listContact.Clear();
                    gvContact.Rows.Add(dtContact.Rows.Count);
                    for (int i = 0; i < dtContact.Rows.Count; i++)
                    {
                        DataRow dr = dtContact.Rows[i];
                        listContact.Add(new FormList(dr["NickName"].ToString(), dr["IP"].ToString(), int.Parse(dr["PORT"].ToString()), dr["Status"].ToString()));
                        gvContact.Rows[i].Cells[0].Value = dr["NickName"].ToString();
                        gvContact.Rows[i].Cells[1].Value = dr["IP"].ToString();
                        gvContact.Rows[i].Cells[2].Value = dr["PORT"].ToString();
                    }
                }
                dtContact.Clear();
            }
        }

        /// <summary>
        /// 重新載入聯絡人清單
        /// </summary>
        private void ReLoadContactList()
        {
            if (this.InvokeRequired)
                this.Invoke(new delegateReloadContactList(this.ReLoadContactList));
            else
            {
                if (listContact.Count > 0)
                {
                    try
                    {
                        for (int i = 0; i < listContact.Count; i++)
                        {
                            FormList frm = listContact[i];
                            if (frm.Status.Equals("Online"))
                            {
                                gvContact.Rows[i].Cells[0].Style.ForeColor = Color.Black;
                                gvContact.Rows[i].Cells[0].Style.SelectionForeColor = Color.Black;
                            }
                            else
                            {
                                gvContact.Rows[i].Cells[0].Style.ForeColor = Color.Gray;
                                gvContact.Rows[i].Cells[0].Style.SelectionForeColor = Color.Gray;
                            }
                        }
                    }
                    catch { }
                }
            }
        }

        /// <summary>
        /// 載入設定
        /// </summary>
        private void LoadSetting()
        {
            DataSet ds = new DataSet();
            dtSetting = Utility.CreateContractTable();
            if (System.IO.File.Exists(strSettingXml))
            {
                ds.ReadXml(strSettingXml);
                if (ds.Tables["Contract"].Rows.Count > 0)
                {
                    try
                    {
                        dtSetting = ds.Tables["Contract"];
                        IP = IPAddress.Parse(dtSetting.Rows[0]["IP"].ToString());
                        PORT = int.Parse(dtSetting.Rows[0]["PORT"].ToString());
                        MyName = dtSetting.Rows[0]["NickName"].ToString();
                        ServerStart();
                    }
                    catch
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("請先設定基本資料");
                FormSetting setting = new FormSetting();
                if (setting.ShowDialog() == DialogResult.OK)
                {
                    LoadSetting();
                }
            }
        }

        /// <summary>
        /// 啟動監聽程式
        /// </summary>
        private void ServerStart()
        {
            //若執行緒已開啟則先停止執行緒
            if (SocketThread != null && SocketThread.IsAlive)
            {
                SocketThread.Abort();
                server.listenerServer.Stop();
            }

            //以新的執行緒開啟監聽程式
            server = new SocketServer(this);
            SocketThread = new Thread(new ThreadStart(server.StartListener));
            SocketThread.IsBackground = true;
            SocketThread.Start();
            OnlineCheckStart();
        }

        /// <summary>
        /// 檢查聯絡人是否在線上
        /// </summary>
        private void OnlineCheckStart()
        {
            OnlineCheck check = new OnlineCheck(this);
            Thread thread = new Thread(new ThreadStart(check.StartCheck));
            thread.IsBackground = true;
            thread.Start();
        }

        /// <summary>
        /// 下線通知
        /// </summary>
        private void OfflineNotice()
        {
            OnlineCheck check = new OnlineCheck(this);
            Thread thread = new Thread(new ThreadStart(check.NoticeStatus));
            thread.IsBackground = true;
            thread.Start();
        }
        #endregion

        #region 公有方法
        /// <summary>
        /// 開啟聊天視窗
        /// </summary>
        /// <param name="frmMsg"></param>
        public void ShowForm(string ContactName, string ContactIP, string ContactPORT)
        {
            if (this.InvokeRequired)
                this.Invoke(new delegateShowForm(this.ShowForm), new object[] { ContactName, ContactIP, ContactPORT });
            else
            {
                string arguments = string.Format("ContactName={0} ContactIP={1} ContactPORT={2} SendName={3} SendIP={4} SendPORT={5}",
                    ContactName,        //聯絡人名稱
                    ContactIP,          //聯絡人 IP
                    ContactPORT,        //聯絡人的 PORT
                    MyName,             //自己的名稱
                    IP.ToString(),      //自己的 IP
                    PORT.ToString());   //自己的 PORT

                ProcessStartInfo info = new ProcessStartInfo(Application.StartupPath + "\\MessageForm.exe", arguments);
                Process.Start(info);
            }
        }

        /// <summary>
        /// 新增聯絡人
        /// </summary>
        /// <param name="name"></param>
        /// <param name="ip"></param>
        /// <param name="port"></param>
        public void AddContact(string name, string ip, string port)
        {
            if (this.InvokeRequired)
                this.Invoke(new delegateAddContact(this.AddContact), new object[] { name, ip, port });
            else
            {
                dtContact.ReadXml(strContactXml);
                DataRow dr = dtContact.NewRow();
                dr["NickName"] = name;
                dr["IP"] = ip;
                dr["PORT"] = port;
                dtContact.Rows.Add(dr);
                dtContact.WriteXml(strContactXml);
                //dtContact.Clear();
                LoadContactList();
            }
        }

        /// <summary>
        /// 更新聯絡人狀態
        /// </summary>
        /// <param name="name"></param>
        /// <param name="status"></param>
        public void UpdateContactStatus(string ip, string status)
        {
            if (this.InvokeRequired)
                this.Invoke(new delegateUpdateContactStatus(this.UpdateContactStatus), new object[] { ip, status });
            else
            {
                try
                {
                    if (listContact.Count > 0)
                    {
                        FormList form = listContact.Find(u => u.IP == ip);
                        if (form != null)
                        {
                            listContact[listContact.IndexOf(form)].Status = status;
                        }
                    }
                }
                catch { }
            }
        }

        public void ReLoadContact()
        {
            ReLoadContactList();
        }
        #endregion

        #region 複寫方法
        /// <summary>
        /// 接收 Windows 訊息
        /// </summary>
        /// <param name="m"></param>
        protected override void DefWndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case Utility.WM_COPYDATA:
                    Utility.COPYDATASTRUCT myStr = new Utility.COPYDATASTRUCT();
                    Type myType = myStr.GetType();
                    myStr = (Utility.COPYDATASTRUCT)m.GetLParam(myType);
                    //listForm.Remove(listForm.Find(u => u.FormName == myStr.lpData));
                    break;

                default:
                    base.DefWndProc(ref m);
                    break;
            }
        }
        #endregion



    }


}
