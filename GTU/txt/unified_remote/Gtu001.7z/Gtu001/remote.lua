local kb = libs.keyboard;

--http://www.unifiedremote.com/api
--http://www.unifiedremote.com/api/libs/keyboard

--@1
actions.test = function()
        --kb.stroke("ctrl", "alt", "delete", "win", "e", "...");
end


actions.left1 = function()
        kb.stroke("left");
end
actions.right1 = function()
        kb.stroke("right");
end

actions.left2 = function()
        kb.stroke("ctrl", "left");
end
actions.right2 = function()
        kb.stroke("ctrl", "right");
end

actions.left3 = function()
        kb.stroke("shift", "left");
end
actions.right3 = function()
        kb.stroke("shift", "right");
end

actions.fullScreen = function()
        kb.stroke("alt", "enter");
end

actions.esc = function()
        kb.stroke("esc");
end

actions.space = function()
        kb.stroke("space");
end
