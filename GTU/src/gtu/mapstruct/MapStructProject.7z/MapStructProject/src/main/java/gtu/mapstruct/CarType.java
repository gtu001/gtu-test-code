package gtu.mapstruct;

public enum CarType {
    SEDAN
}