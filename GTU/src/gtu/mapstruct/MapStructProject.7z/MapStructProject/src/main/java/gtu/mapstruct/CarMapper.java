package gtu.mapstruct;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CarMapper {
    CarMapper INSTANCE = Mappers.getMapper(CarMapper.class);

    @Mappings({ //
            @Mapping(source = "make", target = "make"), //
            @Mapping(source = "numberOfSeats", target = "seatCount"), //
            @Mapping(source = "type", target = "type")//
    })
    CarDto carToCarDto(Car car);
}