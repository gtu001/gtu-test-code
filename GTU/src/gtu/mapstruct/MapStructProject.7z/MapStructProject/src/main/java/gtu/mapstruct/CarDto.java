package gtu.mapstruct;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CarDto {
    private String make;
    private int seatCount;
    private CarType type;

    public CarDto() {
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public int getSeatCount() {
        return seatCount;
    }

    public void setSeatCount(int seatCount) {
        this.seatCount = seatCount;
    }

    public CarType getType() {
        return type;
    }

    public void setType(CarType type) {
        this.type = type;
    }
}