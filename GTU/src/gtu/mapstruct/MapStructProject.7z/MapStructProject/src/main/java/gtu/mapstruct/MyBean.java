package gtu.mapstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class MyBean implements CommandLineRunner {

    @Autowired
    CarMapper mCarMapper;

    public void run(String... args) {
        // given
        Car car = new Car("Morris", 5, CarType.SEDAN);

        // when
        // CarDto carDto = CarMapper.INSTANCE.carToCarDto(car);
        CarDto carDto = mCarMapper.carToCarDto(car);

        // then
        System.out.println("###---" + carDto.getMake());
        System.out.println("###---" + carDto.getSeatCount());
        System.out.println("###---" + carDto.getType());

        System.out.println("---------------------------------");
    }
}